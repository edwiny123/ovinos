﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System;
using cuidadoOvino.App.dominio;
using cuidadoOvino.App.persistencia;

namespace cuidadoOvino.App.console
{
    class Program
    {

        static void Main(string[]args)
        {
            Console.WriteLine("Hello, world");
        }
    } 
}

