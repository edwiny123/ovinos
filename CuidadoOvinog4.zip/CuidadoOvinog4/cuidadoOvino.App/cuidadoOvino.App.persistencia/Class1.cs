﻿namespace cuidadoOvino.App.persistencia;
public class Class1
{

}
