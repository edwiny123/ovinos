using System ;
namespace cuidadoOvino.App.dominio 

{
     public class Ovinos
    {   
        public int Id{get;set;}
        public string Nombre{get;set;}
        public string Color{get;set;}
        public string Especie{get;set;}
        public string Raza{get;set;}
        public string NombreMedicoVeterinario{get;set;}
        public string DuenoOvino{get;set;}


    }
}
