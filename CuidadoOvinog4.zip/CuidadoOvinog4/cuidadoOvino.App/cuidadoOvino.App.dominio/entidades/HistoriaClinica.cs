using System ;

namespace cuidadoOvino.App.dominio

{
    public class HistoriaClinica
    {   
        public int Id{get;set;}
        public string FechaAperturaHistoría{get;set;}
        public string  DuenoOvino{get;set;}
        public string  NombreMedico{get;set;}
        public string  Direccion{get;set;}
    }
}
