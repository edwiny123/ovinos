using System;

namespace cuidadoOvino.App.dominio
{

    public class CuidadoOvino
        {  
            public int Id{get;set;}
            public string Nit{get;set;}
            public string  Nombre{get;set;} 


        }

}