﻿namespace cuidadoOvino.App.dominio;
public class Class1
{

}
